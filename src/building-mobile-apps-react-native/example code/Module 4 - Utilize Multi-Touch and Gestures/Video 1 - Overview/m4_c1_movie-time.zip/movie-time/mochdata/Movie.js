const movie = {
  id: "tt1375666",
  title: "Inception",
  originalTitle: "",
  fullTitle: "Inception (2010)",
  type: "Movie",
  year: "2010",
  image:
    "https://imdb-api.com/images/original/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_Ratio0.6791_AL_.jpg",
  releaseDate: "2010-07-14",
  runtimeMins: "148",
  runtimeStr: "2h 28mins",
  plot:
    "Dom Cobb is a skilled thief, the absolute best in the dangerous art of extraction, stealing valuable secrets from deep within the subconscious during the dream state, when the mind is at its most vulnerable. Cobb's rare ability has made him a coveted player in this treacherous new world of corporate espionage, but it has also made him an international fugitive and cost him everything he has ever loved. Now Cobb is being offered a chance at redemption. One last job could give him his life back but only if he can accomplish the impossible, inception. Instead of the perfect heist, Cobb and his team of specialists have to pull off the reverse: their task is not to steal an idea, but to plant one. If they succeed, it could be the perfect crime. But no amount of careful planning or expertise can prepare the team for the dangerous enemy that seems to predict their every move. An enemy that only Cobb could have seen coming.",
  directors: "Christopher Nolan",
  writers: "Christopher Nolan",
  stars: "Leonardo DiCaprio, Joseph Gordon-Levitt, Ellen Page, Ken Watanabe",
  contentRating: "PG-13",
  imDbRating: "8.8",
  imDbRatingVotes: "1947785",
  metacriticRating: "74",
  boxOffice: {
    budget: "$160,000,000 (estimated)",
    openingWeekendUSA: "$62,785,337, 18 July 2010",
    grossUSA: "$292,576,195",
    cumulativeWorldwideGross: "$829,895,144",
  },
  images: {
    imDbId: "tt1375666",
    title: "Inception",
    fullTitle: "Inception (2010)",
    type: "Movie",
    year: "2010",
    items: [
      {
        title: "Leonardo DiCaprio in Inception (2010)",
        image:
          "https://imdb-api.com/images/original/MV5BZTgyMmQ0MjQtODRhNi00YTM2LTgxMWItMDY0NzI3NDRmYTQyXkEyXkFqcGdeQXVyNTM3MDMyMDQ@._V1_Ratio1.0000_AL_.jpg",
      },
      {
        title: "Leonardo DiCaprio and Ken Watanabe in Inception (2010)",
        image:
          "https://imdb-api.com/images/original/MV5BMjIyNjk1OTgzNV5BMl5BanBnXkFtZTcwOTU0OTk1Mw@@._V1_Ratio1.5000_AL_.jpg",
      },
      {
        title:
          "Leonardo DiCaprio, Tom Berenger, Joseph Gordon-Levitt, Tom Hardy, Cillian Murphy, Ellen Page, and Ken Watanabe in Inception (2010)",
        image:
          "https://imdb-api.com/images/original/MV5BNjMxNjI1Mjc1OV5BMl5BanBnXkFtZTcwMDY0OTk1Mw@@._V1_Ratio1.5000_AL_.jpg",
      },
      {
        title:
          "Leonardo DiCaprio, Christopher Nolan, and Ellen Page in Inception (2010)",
        image:
          "https://imdb-api.com/images/original/MV5BMTk1NDM4MDMwMF5BMl5BanBnXkFtZTcwMjY0OTk1Mw@@._V1_Ratio1.5000_AL_.jpg",
      },
    ],
  },
};

export default movie;
